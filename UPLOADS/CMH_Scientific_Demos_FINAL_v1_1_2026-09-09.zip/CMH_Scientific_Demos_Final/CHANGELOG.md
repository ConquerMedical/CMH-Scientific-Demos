# Final demo consolidation v1.1 — 9 September 2026

## Important CTF correction
- CLS is retained as a validated metric demonstrated on ALS PRO-ACT.
- Only the adjustable response cohort in the public CTF interface is synthetic.
- The demo no longer labels the CLS result itself as synthetic.

## Revised
- Deferra Surgery: final visual base retained; routing corrected to separate course departure from response-relation change; silent shift now flags; high/high routes to reassessment; automatic re-arming removed in favor of reference forming; plain-language four-question panel added.
- Deferra Anaesthesiology: new interactive demonstration using the same Deferra logic with signal adequacy, course departure, response-relation change, four-observation maturity, and explicit no-dose/no-autonomous-control boundary.
- OptiCeil Surgical: synthetic surgical embodiment retained; validated neuronal-calcium reference added and surgical thresholds explicitly separated from validation evidence.
- Acquire: PRO-ACT branching result relabeled consistently as +0.0087 branching reduction.
- CTF: supplied interactive demo included with CLS correctly identified as validated on ALS PRO-ACT while the adjustable cohort is labeled synthetic.
- CMH Interface: rebuilt as an all-nine-engine system map, including Deferra and CTF.
- Authenticated Gateway: capability selector updated to all nine protected products.
- Root demo hub: unified landing page linking every primary and architecture/support demonstration.

## Retained substantially as supplied
- NPIS
- TotemicAI
- TopolAI
- ABP
- AIO
- CMH Guard

## Deployment
The package contains a `site/` directory, `install_all_demos.sh`, and `DEPLOY.md`.
No protected engine source, API key, engine key, admin token, or patient data is included.
