#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SITE="$HERE/site"
REPO="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [ -z "$REPO" ]; then
  echo "ERROR: run this from inside the GitHub repository that will host the public demos." >&2
  exit 1
fi
cd "$REPO"
git checkout main
git pull --ff-only origin main
for path in index.html README.md manifest.json ABP AIO Acquire CTF CMH-Authenticated-Gateway CMH-Guard CMH-Interface Deferra-Surgery Deferra-Anaesthesiology NPIS OptiCeil-Surgical TopolAI TotemicAI; do
  rm -rf "$path"
done
cp -R "$SITE"/* "$REPO"/
git add -A
if git diff --cached --quiet; then
  echo "Nothing changed."
  exit 0
fi
git config user.name "CMH Scientific demos"
git config user.email "41898282+github-actions[bot]@users.noreply.github.com"
git commit -m "Publish final CMH Scientific interactive demos"
git push origin main
echo "SUCCESS. All demos published to main."
