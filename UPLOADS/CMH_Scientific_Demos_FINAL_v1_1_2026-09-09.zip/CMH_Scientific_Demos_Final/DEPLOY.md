# One-ZIP deployment

Recommended: a dedicated public GitHub repository named `CMH-Scientific-Demos`.

1. Create/open a Codespace for the repository.
2. Upload the single final ZIP somewhere in the Codespace.
3. Extract it to `/tmp/cmh-demos`.
4. Run `bash /tmp/cmh-demos/CMH_Scientific_Demos_Final/install_all_demos.sh`.
5. In GitHub: Settings → Pages → Build and deployment → Deploy from a branch → `main` → `/ (root)` → Save.

No API key or protected engine secret belongs in this repository.
